/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.19-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: alhashemya_group
-- ------------------------------------------------------
-- Server version	10.6.19-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(100) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_en` (`name_en`),
  UNIQUE KEY `name_ar` (`name_ar`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name_en`, `name_ar`, `is_active`, `created_at`, `updated_at`) VALUES (1,'Car Batteries','بطاريات سيارات',1,'2024-09-21 11:58:55','2024-09-21 11:58:55');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(100) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `fb_link` varchar(255) DEFAULT NULL,
  `other_link` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `lat` varchar(255) DEFAULT NULL,
  `lng` varchar(255) DEFAULT NULL,
  `website_link` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_en` (`name_en`),
  UNIQUE KEY `name_ar` (`name_ar`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` (`id`, `name_en`, `name_ar`, `logo`, `phone`, `email`, `fb_link`, `other_link`, `address`, `lat`, `lng`, `website_link`, `is_active`, `created_at`, `updated_at`) VALUES (1,'Al-Hashemya Group','مجموعة الهاشمية','images/companies/6546abd0-a8a7-43c7-87d2-0bced0b55107.png','01234567891','hg@gmail.com','facebook.com/alhashemya-group',NULL,'abc','40.730610','-73.935242','https://hg.alhashemya-group.com/',1,'2024-07-04 17:22:38','2024-09-07 22:32:54'),(2,'Mohamed Hashem Saleh','محمد هاشم صالح','images/companies/70e55d9d-39b7-425d-b05d-7ae48d98060b.png','01234567891','mhs@gmail.com','facebook.com/mhs',NULL,'abc','-73.935242','-73.935242','https://mhs.alhashemya-group.com/',1,'2024-07-04 17:26:48','2024-09-17 21:28:39'),(3,'Ak-Power','Ak-Power','images/companies/de4a05e2-1652-4758-92a3-5f7364378a0c.png','01026553777','akpower@gmail.com','facebook.com/ak-power.com',NULL,'abc','-73.935242','-73.935242','https://ak-power.alhashemya-group.com/',1,'2024-07-04 17:30:25','2024-09-17 21:10:17'),(4,'Modern Construction Secret','شركة سر التعمير الحديثة','images/companies/8f8004e6-2461-4a6e-86ba-c08415c395b7.png','966508478305','mcs@alhashemya-group.com',NULL,NULL,'abc','-73.935242','-73.935242','https://mcs.alhashemya-group.com/',1,'2024-09-05 21:26:26','2024-10-21 21:26:20');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_settings_data_rel`
--

DROP TABLE IF EXISTS `company_settings_data_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company_settings_data_rel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `setting_id` int(10) unsigned NOT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `title_ar` varchar(255) DEFAULT NULL,
  `desc_en` varchar(1000) DEFAULT NULL,
  `desc_ar` varchar(1000) DEFAULT NULL,
  `picture` varchar(255) NOT NULL,
  `sequence` tinyint(4) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `link_with_id` int(10) unsigned DEFAULT NULL COMMENT 'link rows with each others',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `company_settings_data_rel_setting_id` (`setting_id`),
  KEY `company_settings_data_rel_company_id` (`company_id`),
  KEY `company_settings_data_rel_link_with_id_foreign` (`link_with_id`),
  CONSTRAINT `company_settings_data_rel_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `company_settings_data_rel_link_with_id_foreign` FOREIGN KEY (`link_with_id`) REFERENCES `company_settings_data_rel` (`id`),
  CONSTRAINT `company_settings_data_rel_setting_id_foreign` FOREIGN KEY (`setting_id`) REFERENCES `settings` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_settings_data_rel`
--

LOCK TABLES `company_settings_data_rel` WRITE;
/*!40000 ALTER TABLE `company_settings_data_rel` DISABLE KEYS */;
INSERT INTO `company_settings_data_rel` (`id`, `company_id`, `setting_id`, `title_en`, `title_ar`, `desc_en`, `desc_ar`, `picture`, `sequence`, `is_active`, `link_with_id`, `created_at`, `updated_at`) VALUES (1,1,1,'Pioneering Excellence Across Industries','لوريم إيبسوم','Al-Hashemya Group is a leading conglomerate with a diverse portfolio spanning construction, energy solutions, and trading. As the parent company of renowned entities such as Alhashemya for Construction and Urban Development, Modern Construction Secret, MHS, and Al Hashemya for Energy Solutions, we are dedicated to delivering exceptional value and innovation in every sector we operate in. Our commitment to quality, sustainability, and client satisfaction drives our mission to shape the future and create lasting legacies. With a focus on excellence and strategic growth, Al-Hashemya Group continues to lead with integrity and vision in all our endeavors.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/home/10a2d315-6286-4e46-a756-02714e35849c.jpeg',NULL,1,NULL,'2024-09-03 21:01:01','2024-09-16 23:49:53'),(2,1,2,'Al-Hashemya Group','مجموعة الهاشمية','Established in 2014, Al-Hashemya General Contracting Company has grown from a small firm into a leading contractor in urban development, with an annual business volume exceeding 1 billion EGP in the governmental sector alone. Known for its exceptional quality and client-focused services, the company’s success is driven by market research and feedback.\r\n\r\nExpanding both locally and globally, Al-Hashemya ventured into trade, supplying projects with materials and equipment that meet strict technical standards. The establishment of **MHS Trade** in Dubai, U.A.E., further supports its global reach through international partnerships.\r\n\r\nRecently, Al-Hashemya launched **Modern Construction Secret for General Contracting and Urban Development** in Riyadh, Saudi Arabia, expanding its presence in the Middle East. Al-Hashemya Group now oversees a diverse portfolio, including its solar energy division, with a continued focus on quality, innovation, and value-for-money solutions.','تأسست شركة الهاشمية للمقاولات العامة في عام 2014، ونمت من شركة صغيرة إلى شركة رائدة في مجال المقاولات والتطوير العمراني، حيث تجاوز حجم أعمالها السنوي مليار جنيه مصري مع القطاع الحكومي فقط. تُعرف الشركة بجودتها الاستثنائية وخدماتها التي تركز على العملاء، ويعتمد نجاحها على أبحاث السوق وردود الفعل من العملاء.\r\n\r\nمن خلال التوسع محليًا ودوليًا، دخلت الهاشمية في مجال التجارة، حيث تزود المشاريع بالمواد والمعدات التي تلبي المعايير الفنية الصارمة. تأسيس **إم إتش إس تريد** في دبي، الإمارات العربية المتحدة، يعزز وصولها العالمي من خلال شراكات دولية.\r\n\r\nمؤخرًا، أطلقت الهاشمية **شركة السر الحديث للمقاولات العامة والتطوير العمراني** في الرياض، المملكة العربية السعودية، مما يعزز وجودها في منطقة الشرق الأوسط. تُشرف مجموعة الهاشمية الآن على مجموعة متنوعة من الأعمال، بما في ذلك قطاع الطاقة الشمسية، مع التركيز المستمر على الجودة والابتكار وحلول القيمة مقابل المال.','images/about-us/67f9762a-a101-430f-89e3-2727354cf86a.png',NULL,1,NULL,'2024-09-03 21:02:44','2024-09-21 09:27:53'),(3,1,3,'Construction','البناء','Al-Hashemya Group\'s construction services are delivered through its companies: Alhashemya for Construction and Urban Development in Egypt and Modern Construction Secret in Saudi Arabia. Our team specializes in large-scale residential, commercial, and infrastructure projects, always maintaining the highest standards of quality, safety, and sustainability.','.يتم تقديم خدمات البناء من خلال شركات مجموعة الهاشمية: الهاشمية للتعمير والتنمية العمرانية في مصر و شركة سر التعمير الحديثة في المملكة العربية السعودية. يتخصص فريقنا في مشاريع الإسكان والتجارية والبنية التحتية الكبيرة، مع الحفاظ دائمًا على أعلى معايير الجودة والسلامة والاستدامة','images/services/3dc339e6-1db9-4f1f-a772-f1f401fdbd38.jpg',1,1,NULL,'2024-09-03 21:03:40','2024-09-16 21:41:22'),(4,1,3,'Electromechanical','الكهروميكانيكية','We provide comprehensive electromechanical services, ensuring seamless integration of electrical and mechanical systems in buildings. Our expert team handles HVAC systems, plumbing, electrical installations, and fire safety systems, ensuring operational efficiency and reliability across all projects.','نقدم خدمات كهروميكانيكية شاملة تضمن تكاملًا سلسًا للأنظمة الكهربائية والميكانيكية في المباني. يتولى فريقنا المتخصص أنظمة التدفئة والتهوية وتكييف الهواء (HVAC) والسباكة والتركيبات الكهربائية وأنظمة السلامة من الحرائق، مما يضمن كفاءة التشغيل والاعتمادية في جميع المشاريع.','images/services/70070831-0b06-4cb5-8a8b-7dadd847e9cb.jpg',2,1,NULL,'2024-09-03 21:04:48','2024-09-16 21:52:48'),(5,1,3,'Solar Energy & Batteries','الطاقة الشمسية والبطاريات','Our partnership with AK Power allows us to provide cutting-edge battery technologies that enhance energy storage solutions and support sustainable energy initiatives. We are committed to delivering superior products that meet the highest standards of efficiency and durability, ensuring that our clients receive dependable and innovative energy solutions.','تقدم شركة الهاشمية لحلول الطاقة، وهي الوكيل لشركة AK Power Batteries (وهي شركة تصنيع صينية رائدة)، حلول طاقة متقدمة. نحن متخصصون في أنظمة الطاقة الشمسية وحلول تخزين البطاريات الموثوقة، مما يساهم في إدارة الطاقة المستدامة والفعالة.','images/services/bb8b53fd-e148-4540-ac57-2f0c66e78513.jpg',3,1,NULL,'2024-09-03 21:05:21','2024-09-16 22:35:30'),(6,1,4,NULL,NULL,'Our mission is to consistently deliver superior contracting, development, and trade services by leveraging advanced technology, market research, and a dedicated team. We strive to foster long-term partnerships, expand our presence globally, and maintain a strong commitment to quality, sustainability, and value-for-money solutions, contributing to the growth and success of our clients and communities.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/missions-and-visions/a08e4a11-81a1-4273-8ca3-a6e461b4455c.jpg',NULL,1,NULL,'2024-09-03 21:06:42','2024-09-21 09:31:21'),(7,1,4,NULL,NULL,'To be a global leader in contracting, urban development, and trade, recognized for delivering innovative, sustainable, and high-quality solutions that drive progress and exceed client expectations across diverse sectors.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/missions-and-visions/afd7a6e1-996d-4162-8485-8c35caaec9a1.jpg',NULL,1,6,'2024-09-03 21:06:42','2024-09-21 09:31:21'),(8,1,5,'Modern Construction Secret','شركة سر التعمير الحديثة',NULL,NULL,'images/partners/0b453165-7288-41aa-9153-806d56a053da.png',1,1,NULL,'2024-09-03 21:07:30','2024-09-16 21:11:33'),(9,1,5,'Mohamed Hashem Saleh','شركة محمد هاشم صالح',NULL,NULL,'images/partners/d7b0c9b8-fc30-4e23-b961-24783eb19016.png',2,1,NULL,'2024-09-03 21:07:48','2024-09-16 21:13:11'),(10,1,5,'Ak Power Egypt','Ak Power Egypt',NULL,NULL,'images/partners/3f3ceb76-2137-4128-b4dd-a17628cb7b21.png',3,1,NULL,'2024-09-03 21:08:06','2024-09-16 21:13:45'),(11,1,6,'National Water Company','شركة المياه الوطنية',NULL,NULL,'images/clients/8ba9caff-beb4-4b15-8dd7-6569130261b5.jpg',1,1,NULL,'2024-09-03 21:08:35','2024-09-21 09:33:34'),(12,1,6,'الهيئة الهندسية للقوات المسلحة','الهيئة الهندسية للقوات المسلحة',NULL,NULL,'images/clients/1f43afe8-c84d-48e7-9dca-d53541394684.jpg',2,1,NULL,'2024-09-03 21:08:57','2024-09-21 09:33:47'),(13,1,6,'Ministry of Housing, Utilities and Urban Communities','وزارة الاسكان و المرافق و المجتمعات العمرانية',NULL,NULL,'images/clients/85e6db31-c202-4992-9a6c-a70975eea8ab.jpg',3,1,NULL,'2024-09-03 21:09:17','2024-09-21 09:34:00'),(14,2,1,'Lorem Ipsum','لوريم إيبسوم','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/home/4dd28ff8-d71c-4922-b380-0b843a4cb2ad.jpeg',NULL,1,NULL,'2024-09-03 21:21:42','2024-09-03 21:22:22'),(15,2,2,'Lorem Ipsum','لوريم إيبسوم','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/about-us/2a9a28e8-9535-4702-9797-d006ce3fbe31.png',NULL,1,NULL,'2024-09-03 21:22:58','2024-09-17 21:29:00'),(16,2,3,'Lorem Ipsum','لوريم إيبسوم','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/services/0f03e123-c8bc-46af-bd08-714b6a53d820.png',1,1,NULL,'2024-09-03 21:23:29','2024-09-17 21:28:11'),(17,2,3,'Lorem Ipsum','لوريم إيبسوم','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/services/cc9cf418-b1fb-45a0-8992-731a8131821a.png',2,1,NULL,'2024-09-03 21:23:56','2024-09-17 21:29:15'),(18,2,3,'Lorem Ipsum','لوريم إيبسوم','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/services/88d88451-e7fd-4647-9807-b4af71658f36.png',3,1,NULL,'2024-09-03 21:24:25','2024-09-17 21:29:33'),(19,2,4,'Lorem Ipsum','لوريم إيبسوم','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/missions-and-visions/3228345d-10d2-420c-9ac1-9be6a3534cb1.png',NULL,1,NULL,'2024-09-03 21:25:17','2024-09-17 21:29:59'),(20,2,4,'Lorem Ipsum','لوريم إيبسوم','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/missions-and-visions/2509d214-fe2f-4a30-a5f8-e48bdba89fd6.png',NULL,1,19,'2024-09-03 21:25:17','2024-09-17 21:29:59'),(21,2,5,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/partners/255f2a09-0305-4119-bf19-b7fe2e60f634.png',1,0,NULL,'2024-09-03 21:25:50','2024-09-21 06:19:54'),(22,2,5,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/partners/d4afaa22-eb52-4d32-bfe4-400a1b16bf6c.png',2,0,NULL,'2024-09-03 21:26:02','2024-09-21 06:20:03'),(23,2,5,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/partners/1370dbea-25e5-4d56-8f82-e798dbebf6d9.png',3,0,NULL,'2024-09-03 21:26:17','2024-09-21 06:20:09'),(24,2,6,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/clients/4f646634-237c-49db-8c2c-76c5f14c33a3.png',1,1,NULL,'2024-09-03 21:26:31','2024-09-17 21:30:19'),(25,2,6,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/clients/c77741b2-1716-4b6a-a092-7220dec28d05.png',2,1,NULL,'2024-09-03 21:27:19','2024-09-17 21:30:36'),(26,2,6,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/clients/b98c2970-8d11-417c-ac39-de98119483db.png',3,1,NULL,'2024-09-03 21:27:33','2024-09-17 21:30:51'),(27,4,1,'Building Excellence with Vision','لوريم إيبسوم','Modern Construction Secret is at the forefront of the construction industry, known for our exceptional craftsmanship and innovative approach. We specialize in creating iconic structures that define the urban landscape, from residential and commercial buildings to complex architectural projects. Our commitment to quality, sustainability, and client satisfaction drives us to exceed expectations and deliver outstanding results on every project.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/home/038cd684-8286-4df4-8367-6333b59d4ef0.jpeg',NULL,1,NULL,'2024-09-06 07:51:42','2024-09-16 23:48:21'),(28,4,2,'Modern Construction Secret','شركة سر التعمير الحديثة','Modern Construction Secret is a reputable construction company with a strong track \r\nrecord of delivering exceptional projects. Our team of experienced professionals is \r\ndedicated to exceeding client expectations by providing innovative \r\nsolutions, meticulous craftsmanship, and a collaborative approach. We are \r\ncommitted to sustainable practices and strive to create lasting legacies in every \r\nproject we undertake.','شركة سر التعمير الحديثة هي شركة بناء ذات سمعة مرموقة وسجل حافل بتقديم مشاريع استثنائية. فريقنا من المحترفين ذوي الخبرة ملتزم بتجاوز توقعات العملاء من خلال تقديم حلول مبتكرة، وصنعة دقيقة، ونهج تعاوني. نحن ملتزمون بالممارسات المستدامة ونسعى لخلق إرث دائم في كل مشروع نقوم به.','images/about-us/3c930057-e1c8-4c78-b655-a74400a08f67.png',NULL,1,NULL,'2024-09-06 07:52:24','2024-10-21 21:02:21'),(29,4,3,'Commercial Market','السوق التجاري','10 Stores\r\n Each store has a height of \r\n6.5 meters.\r\n Works Included\r\n Concrete works, internal \r\nand external finishes, \r\nfacade treatments, MEP \r\nEncompasses a total built\r\n up area of 1200 m².\r\n works, and landscaping','10 محلات\r\n\r\nارتفاع كل محل: 6.5 متر\r\nالأعمال تشمل:\r\nالأعمال الخرسانية\r\nالتشطيبات الداخلية والخارجية\r\nمعالجة الواجهات\r\nأعمال الأنظمة الكهروميكانيكية (MEP)\r\nأعمال اللاندسكيب\r\nإجمالي المساحة المبنية: 1200 م²','images/services/030c6dd6-be12-4470-b66d-fd29a94e2be2.png',5,1,NULL,'2024-09-06 07:53:17','2024-10-21 21:04:03'),(30,4,3,'Mixed Use Building Project','مشروع مبني متعدد الاستخدامات','The project involves the construction of two residential, commercial, and administrative buildings standing at 34 meters tall. The work includes concrete, interior and exterior finishing, MEP systems, and landscaping over a total built up area of 57,000 square meters. (basement, ground floor, 7 repeated floors, roof)','يتضمن المشروع بناء مبنيين سكنيين وتجاريين وإداريين بارتفاع 34 مترًا. تشمل الأعمال الخرسانية، التشطيبات الداخلية والخارجية، أنظمة الكهروميكانيكية (MEP)، وأعمال اللاندسكيب على إجمالي مساحة مبنية تبلغ 57,000 متر مربع. (بدروم، طابق أرضي، 7 طوابق متكررة، وسطح).','images/services/6b51cec1-12c6-43a1-a6cf-aac59b2c6e1d.jpg',1,1,NULL,'2024-09-06 07:53:41','2024-10-21 21:40:46'),(31,4,3,'Infrastructure Hitteen Project','لوريم إيبسوم','The project involves all the infrastructure\r\n and Sanitary work for the whole district.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/services/0ba6d19f-73a4-4c06-9c08-76894f12e1cd.jpg',3,1,NULL,'2024-09-06 07:54:11','2024-10-21 21:19:15'),(32,4,4,NULL,NULL,'Our mission is to deliver exceptional construction services that meet and exceed our clients\' expectations. We achieve this through meticulous planning, expert execution, and a commitment to excellence in every project we undertake.','مهمتنا هي تقديم خدمات بناء استثنائية تلبي وتتجاوز توقعات عملائنا. نحقق ذلك من خلال التخطيط الدقيق، والتنفيذ المتقن، والالتزام بالتميز في كل مشروع نقوم به.','images/missions-and-visions/9eb3c04d-8c8f-43eb-80db-4fdf3751729d.jpg',NULL,1,NULL,'2024-09-06 07:55:48','2024-09-19 05:37:58'),(33,4,4,NULL,NULL,'Our vision is to be a leading construction company, renowned for its exceptional projects and unwavering commitment to client satisfaction. We aspire to shape the built environment, creating sustainable and innovative structures that enhance communities and inspire future generations.','رؤيتنا هي أن نكون شركة رائدة في مجال البناء، مشهورة بمشاريعها الاستثنائية والتزامها الثابت برضا العملاء. نسعى لتشكيل البيئة العمرانية من خلال إنشاء هياكل مستدامة ومبتكرة تعزز المجتمعات وتلهم الأجيال القادمة.','images/missions-and-visions/4f1d7e52-9135-49d9-b55d-fdc5a21ddcb6.jpg',NULL,1,32,'2024-09-06 07:55:48','2024-09-19 05:37:58'),(34,4,5,'Arch Plan','Arch Plan',NULL,NULL,'images/partners/ad4d7fc6-02ef-4be7-b4c1-e69f9e707cd4.jpg',2,1,NULL,'2024-09-06 07:56:09','2024-09-19 07:03:13'),(35,4,5,'Yard Consulting Engineers','الياردة للاستشارات الهندسية',NULL,NULL,'images/partners/1963fcb6-669b-4b69-be1a-78b7e57b0503.jpg',1,1,NULL,'2024-09-06 07:56:28','2024-09-19 07:02:36'),(36,4,5,'Dr. Amr Abdelrahman Structures','استشاري الاعمال الانشائية د. عمرو عبدالرحمن',NULL,NULL,'images/partners/bea46a2a-f1a9-4943-8861-3cd569165a32.png',3,0,NULL,'2024-09-06 07:56:59','2024-09-19 07:04:39'),(37,4,6,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/clients/848afef6-c8c9-486c-8970-ab1f39be64b9.jpg',1,1,NULL,'2024-09-06 07:57:30','2024-09-19 07:05:53'),(38,4,6,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/clients/d6c5d315-8ffd-4c46-aeff-5082c6ef69ac.jpg',2,1,NULL,'2024-09-06 07:57:52','2024-09-19 07:06:31'),(39,4,6,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/clients/be2f7e87-3625-44f9-9afc-1ca0eb10b6a8.jpg',3,1,NULL,'2024-09-06 07:58:12','2024-09-19 07:11:02'),(40,3,1,'Innovating Energy for a Sustainable Future','لوريم إيبسوم','Al Hashemya for Energy Solutions is a leading provider of advanced energy technologies, specializing in renewable energy systems and reliable battery solutions. Our mission is to drive the transition to sustainable energy by offering cutting-edge products and services that enhance efficiency and reduce environmental impact. With a focus on innovation and customer satisfaction, we are dedicated to powering a cleaner, more sustainable future.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/home/02801e58-eba1-41a5-afe8-be62b9eaacec.jpeg',NULL,1,NULL,'2024-09-07 07:49:14','2024-09-17 21:17:45'),(41,3,2,'About AK Power Batteries','عن بطاريات AK Power','AK Power Batteries is a leading Chinese manufacturer of advanced, high-performance battery solutions. Al-Hashemya is proud to be the exclusive agent for AK Power in Egypt, playing a key role in bringing these cutting-edge technologies to the Egyptian market.\r\n\r\nThrough our partnership with AK Power, Al-Hashemya offers innovative energy storage solutions that support sustainable energy projects and enhance operational efficiency. We are committed to delivering high-quality battery products that ensure reliability and performance, making Al-Hashemya the trusted source for advanced energy solutions in Egypt.','بطاريات AK Power هي شركة صينية رائدة في تصنيع حلول البطاريات المتطورة ذات الأداء العالي والموثوقية. تفخر شركة الهاشمية بكونها الوكيل المعتمد لشركة AK Power في مصر، حيث نلعب دورًا محوريًا في تقديم هذه التقنيات المتقدمة للسوق المصري.\r\n\r\nمن خلال شراكتنا مع AK Power، تقدم الهاشمية لعملائها حلولاً مبتكرة لتخزين الطاقة، تدعم مشروعات الطاقة المستدامة وتعزز الكفاءة التشغيلية. نحن ملتزمون بتوفير منتجات بطاريات عالية الجودة، تضمن موثوقية وأداءً يتناسب مع احتياجات العملاء، مما يجعل الهاشمية الوجهة الموثوقة لحلول الطاقة المتطورة في مصر.','images/about-us/3eee788b-65af-4989-9e55-99221cf942ad.jpg',NULL,1,NULL,'2024-09-07 07:49:43','2024-09-17 21:16:30'),(42,3,3,'Lorem Ipsum','لوريم إيبسوم','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/services/3ccf54c1-8a09-40af-8ca3-c5102e34750e.png',1,1,NULL,'2024-09-07 07:50:11','2024-09-07 07:50:11'),(43,3,3,'Lorem Ipsum','لوريم إيبسوم','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/services/6c27fd4c-8a2c-46e7-bbbb-40d900caf031.png',2,1,NULL,'2024-09-07 07:50:32','2024-09-07 07:50:32'),(44,3,3,'Lorem Ipsum','لوريم إيبسوم','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.','images/services/1eaa3ecf-bf29-4582-96bf-1c2f7d78d5c5.png',3,1,NULL,'2024-09-07 07:50:57','2024-09-07 07:50:57'),(45,3,4,NULL,'لوريم إيبسوم','Our mission is to deliver comprehensive energy solutions that meet the growing demand for renewable energy. We are committed to providing high-quality solar energy systems and advanced energy storage technologies that empower businesses and communities. By focusing on innovation, sustainability, and customer satisfaction, we aim to contribute to the region’s renewable energy goals and create a lasting impact on the environment.','مهمتنا هي تقديم حلول شاملة للطاقة تلبي الطلب المتزايد على الطاقة المتجددة. نحن ملتزمون بتوفير أنظمة الطاقة الشمسية عالية الجودة وتقنيات تخزين الطاقة المتقدمة التي تمكّن الشركات والمجتمعات. من خلال التركيز على الابتكار والاستدامة ورضا العملاء، نسعى للمساهمة في تحقيق أهداف الطاقة المتجددة في المنطقة وإحداث تأثير دائم على البيئة.','images/missions-and-visions/cd5bc9b8-5498-4745-8010-5c58b7c2c13e.png',NULL,1,NULL,'2024-09-07 07:51:41','2024-09-23 18:47:11'),(46,3,4,NULL,'لوريم إيبسوم','To become a leading force in energy solutions and solar power in Egypt and the region, driving the transition to sustainable energy by offering innovative, reliable, and efficient technologies that support a greener future.','أن نصبح قوة رائدة في حلول الطاقة والطاقة الشمسية في مصر والمنطقة، من خلال قيادة التحول نحو الطاقة المستدامة عبر تقديم تقنيات مبتكرة وموثوقة وفعالة تدعم مستقبلًا أكثر اخضرارًا.','images/missions-and-visions/a7fa0490-d267-4014-8e20-880dc8a597ba.png',NULL,1,45,'2024-09-07 07:51:41','2024-09-23 18:47:11'),(47,3,5,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/partners/d8716cd0-052a-4b4f-9c81-1f9fe748f0af.png',1,1,NULL,'2024-09-07 07:51:59','2024-09-17 21:23:45'),(48,3,5,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/partners/464aa5ac-369b-44ab-91ed-c147b22558bc.png',2,1,NULL,'2024-09-07 07:52:09','2024-09-17 21:24:14'),(49,3,5,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/partners/7489671f-7cdc-4db8-a724-25bd1b7dc115.png',3,1,NULL,'2024-09-07 07:52:20','2024-09-17 21:24:28'),(50,3,6,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/clients/0bc99000-3576-469b-8809-983b4350cc73.png',1,1,NULL,'2024-09-07 07:52:39','2024-09-07 07:52:39'),(51,3,6,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/clients/1c04d722-0df6-449a-9815-330046839bd0.png',2,1,NULL,'2024-09-07 07:52:54','2024-09-07 07:52:54'),(52,3,6,'Lorem Ipsum','لوريم إيبسوم',NULL,NULL,'images/clients/3e45967a-80dd-4459-bfaa-45748ddd35ed.png',3,1,NULL,'2024-09-07 07:53:05','2024-09-07 07:53:05'),(54,1,3,'Other Services','خدمات أخرى','Wood Industry: We offer high-quality wood products, including custom furniture and specialized woodworks for construction and interior design projects.\r\nDoors & More: Our range of premium doors and related accessories are designed to meet both aesthetic and security requirements.\r\nUPVC Roofing Sheets: Durable and lightweight UPVC roofing solutions suitable for residential, commercial, and industrial applications.','صناعة الأخشاب: نقدم منتجات خشبية عالية الجودة، بما في ذلك الأثاث المخصص والأعمال الخشبية المتخصصة لمشاريع البناء والتصميم الداخلي.\r\nالأبواب والمزيد: نقدم مجموعة من الأبواب الفاخرة والإكسسوارات المرتبطة بها التي تلبي متطلبات الجمال والأمان.\r\nألواح تسقيف UPVC: حلول تسقيف UPVC المتينة والخفيفة الوزن، المناسبة للتطبيقات السكنية والتجارية والصناعية.','images/services/523ba797-d297-4fba-ab2a-5ac9197fd26f.jpg',5,1,NULL,'2024-09-16 22:29:44','2024-09-16 22:34:44'),(55,1,3,'Trading','التجارة','MHS (Mohamed Hashem Saleh) manages our trading operations in the UAE, specializing in the distribution of construction materials, energy solutions, and other industrial goods. We provide high-quality products and build long-term partnerships with suppliers and clients across the region.','تدير شركة MHS (محمد هاشم صالح) عملياتنا التجارية في الإمارات العربية المتحدة، وهي متخصصة في توزيع مواد البناء وحلول الطاقة وغيرها من السلع الصناعية. نقدم منتجات عالية الجودة ونبني شراكات طويلة الأمد مع الموردين والعملاء في جميع أنحاء المنطقة.','images/services/83eeb37d-3f10-4e9a-a479-f3d8ad902477.jpg',4,1,NULL,'2024-09-16 22:34:02','2024-09-16 22:34:02'),(56,4,5,'5+UDC','5+ UDC',NULL,NULL,'images/partners/f7e0168d-5cd9-4883-8772-c4afe289dc06.jpg',4,1,NULL,'2024-09-16 23:03:36','2024-09-19 07:04:12'),(57,4,5,'Crown Home Consultants','كراون هوم للاستشارات الهندسية',NULL,NULL,'images/partners/fdc891d6-108c-4bf9-be60-4d4efb3614a5.jpg',5,1,NULL,'2024-09-16 23:04:56','2024-09-19 07:05:09'),(58,4,6,'الهيئة الهندسية للقوات المسلحة','الهيئة الهندسية للقوات المسلحة',NULL,NULL,'images/clients/46f0c9ae-e94c-4152-8ca3-f1eabf960656.jpg',4,1,NULL,'2024-09-16 23:08:29','2024-09-19 07:11:39'),(59,4,6,'yathreb Contracting','شركة ياثرب للمقاولات',NULL,NULL,'images/clients/aacc7ebb-4281-47c7-896b-2eccbdb8fcd5.jpg',5,1,NULL,'2024-09-16 23:09:26','2024-09-19 07:09:06'),(60,4,6,'Engineering Company for Integrated Projects','الشركة الهندسية للاعمال المتكاملة',NULL,NULL,'images/clients/e284b866-e1a2-46be-a7f3-cdcde659904b.jpg',6,1,NULL,'2024-09-16 23:10:54','2024-09-19 07:09:24'),(61,4,3,'Oasis Project','مشروع الواحة','The Project involves Construction of 2 residential and commercial buildings with height= 50m ( Concrete works, internal, external, and facades finish ing works, MEP works, and site layout works), As 3 buildings have (basement, ground floor, 7 repeated floors, 1 duplex floor) and 1 Building have (basement, ground floor, 9 repeated floors) with total built up area = 27,725m2','المشروع يتضمن بناء مبنيين سكنيين وتجاريين بارتفاع 50 مترًا (أعمال خرسانية، تشطيبات داخلية وخارجية وتشطيبات الواجهات، أعمال الأنظمة الكهروميكانيكية (MEP)، وأعمال تخطيط الموقع)، حيث تتكون 3 مبانٍ من (بدروم، طابق أرضي، 7 طوابق متكررة، طابق دوبلكس واحد)، ومبنى واحد يتكون من (بدروم، طابق أرضي، 9 طوابق متكررة)، بإجمالي مساحة مبنية تبلغ 27,725 متر مربع','images/services/b1d31f1c-485d-4d5f-87e4-5ee95a77e359.jpg',2,1,NULL,'2024-09-16 23:35:00','2024-10-21 21:40:37');
/*!40000 ALTER TABLE `company_settings_data_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `groups_company_id_foreign` (`company_id`),
  CONSTRAINT `groups_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` (`id`, `name`, `company_id`, `is_active`, `created_at`, `updated_at`) VALUES (1,'Super Admins Group',1,1,'2024-08-10 14:19:19','2024-08-31 13:11:49'),(2,'Super Admins Group',2,1,'2024-08-10 16:42:09','2024-08-10 16:43:09'),(3,'Super Admins Group',3,1,'2024-08-10 19:58:53','2024-08-10 19:58:53'),(5,'Super Admins Group',4,1,'2024-09-05 21:27:44','2024-09-05 21:27:44');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned DEFAULT NULL,
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `phone_number` varchar(50) NOT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `body` varchar(255) NOT NULL,
  `is_checked` tinyint(1) NOT NULL DEFAULT 0,
  `company_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `messages_product_id_foreign` (`product_id`),
  KEY `messages_company_id_foreign` (`company_id`),
  CONSTRAINT `messages_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `messages_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_details`
--

DROP TABLE IF EXISTS `product_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `model` varchar(50) DEFAULT NULL,
  `capacity` varchar(50) DEFAULT NULL,
  `voltage` varchar(50) DEFAULT NULL,
  `width` varchar(50) DEFAULT NULL,
  `length` varchar(50) DEFAULT NULL,
  `height` varchar(50) DEFAULT NULL,
  `total_height` varchar(50) DEFAULT NULL,
  `gross_weight` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_details_product_id` (`product_id`),
  CONSTRAINT `product_details_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_details`
--

LOCK TABLES `product_details` WRITE;
/*!40000 ALTER TABLE `product_details` DISABLE KEYS */;
INSERT INTO `product_details` (`id`, `product_id`, `model`, `capacity`, `voltage`, `width`, `length`, `height`, `total_height`, `gross_weight`, `created_at`, `updated_at`) VALUES (1,1,'KL370090G','5000','42','50','100','50','20','30','2024-09-21 12:06:51','2024-09-21 12:22:52'),(2,2,'KL370090G','5000','42','50','100','50','20','30','2024-09-21 12:24:57','2024-09-21 12:24:57'),(3,3,'KL370090G','5000','42','50','100','50','20','30','2024-09-21 12:24:57','2024-09-21 12:29:31'),(4,4,'KL370090G','5000','42','50','100','50','20','30','2024-09-21 12:24:57','2024-09-21 12:29:45'),(5,5,'KL370090G','5000','42','50','100','50','20','30','2024-09-21 12:24:57','2024-09-21 12:31:14'),(6,6,'KL370090G','5000','42','50','100','50','20','30','2024-09-21 12:24:57','2024-09-21 12:31:40'),(7,7,'KL370090G','5000','42','50','100','50','20','30','2024-09-21 12:24:57','2024-09-21 12:37:16'),(8,8,'KL370090G','5000','42','50','100','50','20','30','2024-09-21 12:24:57','2024-09-21 12:37:27'),(9,9,'KL370090G','5000','42','50','100','50','20','30','2024-09-21 12:24:57','2024-09-21 12:37:40'),(10,10,'KL370090G','5000','42','50','100','50','20','30','2024-09-21 12:24:57','2024-09-21 12:37:52'),(11,11,'KL370090G','5000','42','50','100','50','20','30','2024-09-21 12:24:57','2024-09-21 12:39:00'),(12,12,'KL370090G','5000','42','50','100','50','20','30','2024-09-21 12:24:57','2024-09-21 12:39:15');
/*!40000 ALTER TABLE `product_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_info`
--

DROP TABLE IF EXISTS `product_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `type` varchar(50) NOT NULL COMMENT 'application or feature',
  `name_en` varchar(255) DEFAULT NULL,
  `name_ar` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_info_product_id` (`product_id`),
  CONSTRAINT `product_info_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_info`
--

LOCK TABLES `product_info` WRITE;
/*!40000 ALTER TABLE `product_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_code` varchar(100) NOT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `name_en` varchar(255) NOT NULL,
  `name_ar` varchar(255) NOT NULL,
  `desc_en` varchar(1000) DEFAULT NULL,
  `desc_ar` varchar(1000) DEFAULT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `company_id` int(10) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_code`),
  KEY `products_company_id_foriegn` (`company_id`),
  KEY `products_category_id_foriegn` (`category_id`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `products_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`id`, `product_code`, `picture`, `name_en`, `name_ar`, `desc_en`, `desc_ar`, `category_id`, `company_id`, `is_active`, `created_at`, `updated_at`) VALUES (1,'1000','images/products/8162e959-8353-4df3-97ed-30fbbacf13da.jpg','Electric Planer Brandix','Electric Planer Brandix','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.',1,3,1,'2024-09-21 12:06:51','2024-09-21 12:22:52'),(2,'1001','images/products/3bbe07f3-6d26-43a3-86bc-be04f83ec068.jpg','Electric Planer Brandix','Electric Planer Brandix','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.',1,3,1,'2024-09-21 12:24:57','2024-09-21 12:24:57'),(3,'1003','images/products/4ce03cc2-b8c0-48ab-aab1-872c1f09d49b.jpg','Electric Planer Brandix','Electric Planer Brandix','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.',1,3,1,'2024-09-21 12:24:57','2024-09-21 12:29:31'),(4,'1004','images/products/fdb287f3-c259-4f8c-82ab-4cd0402e94f5.jpg','Electric Planer Brandix','Electric Planer Brandix','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.',1,3,1,'2024-09-21 12:24:57','2024-09-21 12:29:45'),(5,'1005','images/products/a9ffaf01-ba14-40d7-913b-0530d0c971bf.jpg','Electric Planer Brandix','Electric Planer Brandix','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.',1,3,1,'2024-09-21 12:24:57','2024-09-21 12:31:14'),(6,'1006','images/products/5839ccff-4839-431e-af1d-eeb03f913de4.jpg','Electric Planer Brandix','Electric Planer Brandix','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.',1,3,1,'2024-09-21 12:24:57','2024-09-21 12:31:40'),(7,'1007','images/products/58754f3a-c3fa-47b3-b98f-bfbe695fffa9.jpg','Electric Planer Brandix','Electric Planer Brandix','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.',1,3,1,'2024-09-21 12:24:57','2024-09-21 12:37:16'),(8,'1008','images/products/c7be67e5-f45b-4c0a-aac1-5aa8c4a465f7.jpg','Electric Planer Brandix','Electric Planer Brandix','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.',1,3,1,'2024-09-21 12:24:57','2024-09-21 12:37:27'),(9,'1009','images/products/bbd3e3cf-8030-47d2-87f5-0ced6ff93071.jpg','Electric Planer Brandix','Electric Planer Brandix','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.',1,3,1,'2024-09-21 12:24:57','2024-09-21 12:37:40'),(10,'1010','images/products/91e84fec-1e7c-4c53-bd96-61e4f7bbaef4.jpg','Electric Planer Brandix','Electric Planer Brandix','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.',1,3,1,'2024-09-21 12:24:57','2024-09-21 12:37:52'),(11,'1011','images/products/a1e22cbb-9437-4808-b8df-4861281892ad.jpg','Electric Planer Brandix','Electric Planer Brandix','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.',1,3,1,'2024-09-21 12:24:57','2024-09-21 12:39:00'),(12,'1012','images/products/36bb9770-2f8a-40a0-abd9-5aaa9bcafea7.jpg','Electric Planer Brandix','Electric Planer Brandix','Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد كان لوريم إيبسوم هو النص الوهمي القياسي في هذه الصناعة منذ القرن السادس عشر، عندما أخذت طابعة غير معروفة لوح الكتابة وخلطته لصنع نموذج كتاب. لقد صمدت ليس فقط لخمسة قرون، بل قفزت أيضًا إلى التنضيد الإلكتروني، وبقيت دون تغيير بشكل أساسي. انتشر بشكل كبير في ستينيات القرن الماضي مع إصدار أوراق Letraset التي تحتوي على مقاطع لوريم إيبسوم، ومؤخراً مع ظهور برامج النشر المكتبي مثل Aldus PageMaker والتي تضمنت إصدارات لوريم إيبسوم.',1,3,1,'2024-09-21 12:24:57','2024-09-21 12:39:15');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_en` varchar(100) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `action_route` varchar(255) DEFAULT NULL,
  `sequence` int(11) DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `settings_parent_id_foreign` (`parent_id`),
  CONSTRAINT `settings_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `settings` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` (`id`, `name_en`, `name_ar`, `icon`, `action_route`, `sequence`, `parent_id`, `created_at`, `updated_at`) VALUES (1,'Home','الصفحة الرئيسية','fas fa-home','showHome',3,NULL,'2024-07-04 17:37:37','2024-07-04 17:37:37'),(2,'About Us','معلوماتنا','fas fa-address-card','showAboutUs',4,NULL,'2024-07-04 17:37:37','2024-07-04 17:37:37'),(3,'Services','خدماتنا','fas fa-wrench','showServices',5,NULL,'2024-07-04 17:41:26','2024-07-04 17:41:26'),(4,'Mission And Vision','المهمة و الرؤية','fas fa-compass','showMissionsAndVisions',6,NULL,'2024-07-04 17:43:03','2024-07-04 17:43:03'),(5,'Partners','الشركاء','fas fa-handshake','showPartners',7,NULL,'2024-07-04 17:44:48','2024-07-04 17:44:48'),(6,'Clients','العملاء','fas fa-users','showClients',8,NULL,'2024-07-04 17:45:30','2024-07-04 17:45:30'),(7,'Messages','الرسائل','fas fa-comments','showMessages',9,NULL,'2024-07-04 17:46:07','2024-07-04 17:46:07'),(8,'Products','المنتجات','fab fa-product-hunt','showProducts',10,NULL,'2024-07-04 17:46:54','2024-07-04 17:46:54'),(9,'Category','الأقسام','fas fa-list-alt','showCategories',11,NULL,'2024-07-04 19:47:06','2024-07-04 19:47:06'),(10,'Company','الشركة','fa fa-building','showCompany',2,NULL,'2024-07-04 19:47:06','2024-07-04 19:47:06'),(11,'Settings','الأعدادات','fa fa-cog',NULL,100,NULL,'2024-08-10 14:02:09','2024-08-10 14:02:09'),(12,'Groups','المجموعات','fas fa-user-friends','showGroups',1,11,'2024-07-04 19:47:06','2024-07-04 19:47:06'),(13,'Users','المستخدمين','fas fa-users','showUsers',2,11,'2024-08-10 16:47:30','2024-08-10 16:47:30'),(14,'Dashboard','لوحة القيادة','fas fa-bars','dashboard',1,NULL,'2024-08-11 14:16:50','2024-08-11 14:16:50');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings_meta_data`
--

DROP TABLE IF EXISTS `settings_meta_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings_meta_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_id` int(10) unsigned NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `settings_meta_data_setting_id` (`setting_id`),
  CONSTRAINT `settings_meta_data_setting_id_foreign` FOREIGN KEY (`setting_id`) REFERENCES `settings` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings_meta_data`
--

LOCK TABLES `settings_meta_data` WRITE;
/*!40000 ALTER TABLE `settings_meta_data` DISABLE KEYS */;
INSERT INTO `settings_meta_data` (`id`, `setting_id`, `table_name`, `created_at`, `updated_at`) VALUES (1,1,'company_settings_data_rel','2024-07-04 17:51:05','2024-07-04 17:51:05'),(2,2,'company_settings_data_rel','2024-07-04 17:51:05','2024-07-04 17:51:05'),(3,3,'company_settings_data_rel','2024-07-04 17:51:15','2024-07-04 17:51:15'),(4,4,'company_settings_data_rel','2024-07-04 17:51:15','2024-07-04 17:51:15'),(5,5,'company_settings_data_rel','2024-07-04 17:51:27','2024-07-04 17:51:27'),(6,6,'company_settings_data_rel','2024-07-04 17:51:27','2024-07-04 17:51:27'),(7,7,'messages','2024-07-04 17:51:37','2024-07-04 17:51:37'),(8,8,'products','2024-07-04 17:53:06','2024-07-04 17:53:06'),(9,9,'categories','2024-07-04 19:50:21','2024-07-04 19:50:21'),(10,10,'companies','2024-07-04 19:50:21','2024-07-04 19:50:21'),(11,12,'groups','2024-08-30 16:52:05','2024-08-30 16:52:05'),(12,13,'users','2024-08-30 16:52:05','2024-08-30 16:52:05');
/*!40000 ALTER TABLE `settings_meta_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_groups_user_id_foreign` (`user_id`),
  KEY `user_groups_group_id_foreign` (`group_id`),
  CONSTRAINT `user_groups_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`),
  CONSTRAINT `user_groups_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups`
--

LOCK TABLES `user_groups` WRITE;
/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
INSERT INTO `user_groups` (`id`, `user_id`, `group_id`, `is_active`, `created_at`, `updated_at`) VALUES (1,1,1,1,'2024-08-10 14:31:58','2024-08-10 14:31:58'),(4,1,2,1,'2024-08-11 13:57:33','2024-08-11 13:57:33'),(5,1,3,1,'2024-08-11 13:57:33','2024-08-11 13:57:33'),(12,1,5,1,'2024-09-05 21:28:10','2024-09-05 21:28:10');
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups_companies_cards`
--

DROP TABLE IF EXISTS `user_groups_companies_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_groups_companies_cards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(10) unsigned NOT NULL,
  `menu_id` int(10) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_groups_companies_cards_menu_id_foreign` (`menu_id`),
  KEY `user_groups_companies_cards_group_id_foreign` (`group_id`),
  CONSTRAINT `user_groups_companies_cards_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`),
  CONSTRAINT `user_groups_companies_cards_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `settings` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups_companies_cards`
--

LOCK TABLES `user_groups_companies_cards` WRITE;
/*!40000 ALTER TABLE `user_groups_companies_cards` DISABLE KEYS */;
INSERT INTO `user_groups_companies_cards` (`id`, `group_id`, `menu_id`, `is_active`, `created_at`, `updated_at`) VALUES (1,1,1,1,'2024-08-10 14:29:02','2024-08-31 13:11:49'),(2,1,2,1,'2024-08-10 14:29:02','2024-08-31 13:11:49'),(3,1,3,1,'2024-08-10 14:29:19','2024-08-31 13:11:49'),(4,1,4,1,'2024-08-10 14:29:19','2024-08-31 13:11:49'),(5,1,5,1,'2024-08-10 14:29:35','2024-08-31 13:11:49'),(6,1,6,1,'2024-08-10 14:29:35','2024-08-31 13:11:49'),(7,1,7,1,'2024-08-10 14:29:46','2024-08-31 13:11:49'),(8,1,10,1,'2024-08-10 14:30:08','2024-08-31 13:11:49'),(9,1,11,1,'2024-08-10 14:30:08','2024-08-31 13:11:49'),(10,1,12,1,'2024-08-10 15:42:16','2024-08-31 13:11:49'),(11,1,13,1,'2024-08-10 16:48:03','2024-08-31 13:11:49'),(12,1,14,1,'2024-08-11 14:17:42','2024-08-31 13:11:49'),(18,2,1,1,'2024-08-10 14:29:02','2024-08-10 14:29:02'),(19,2,2,1,'2024-08-10 14:29:02','2024-08-10 14:29:02'),(20,2,3,1,'2024-08-10 14:29:19','2024-08-10 14:29:19'),(21,2,4,1,'2024-08-10 14:29:19','2024-08-10 14:29:19'),(22,2,5,1,'2024-08-10 14:29:35','2024-08-10 14:29:35'),(23,2,6,1,'2024-08-10 14:29:35','2024-08-10 14:29:35'),(24,2,7,1,'2024-08-10 14:29:46','2024-08-10 14:29:46'),(25,2,10,1,'2024-08-10 14:30:08','2024-08-10 14:30:08'),(26,2,11,1,'2024-08-10 14:30:08','2024-08-10 14:30:08'),(27,2,12,1,'2024-08-10 15:42:16','2024-08-10 15:42:16'),(28,2,13,1,'2024-08-10 16:48:03','2024-08-10 16:48:03'),(29,2,14,1,'2024-08-11 14:17:42','2024-08-11 14:17:42'),(30,3,1,1,'2024-08-10 14:29:02','2024-08-10 14:29:02'),(31,3,2,1,'2024-08-10 14:29:02','2024-08-10 14:29:02'),(32,3,3,1,'2024-08-10 14:29:19','2024-08-10 14:29:19'),(33,3,4,1,'2024-08-10 14:29:19','2024-08-10 14:29:19'),(34,3,5,1,'2024-08-10 14:29:35','2024-08-10 14:29:35'),(35,3,6,1,'2024-08-10 14:29:35','2024-08-10 14:29:35'),(36,3,7,1,'2024-08-10 14:29:46','2024-08-10 14:29:46'),(37,3,10,1,'2024-08-10 14:30:08','2024-08-10 14:30:08'),(38,3,11,1,'2024-08-10 14:30:08','2024-08-10 14:30:08'),(39,3,12,1,'2024-08-10 15:42:16','2024-08-10 15:42:16'),(40,3,13,1,'2024-08-10 16:48:03','2024-08-10 16:48:03'),(41,3,14,1,'2024-08-11 14:17:42','2024-08-11 14:17:42'),(42,3,8,1,'2024-08-23 11:53:36','2024-08-23 11:53:36'),(43,3,9,1,'2024-08-23 11:53:36','2024-08-23 11:53:36'),(44,5,1,1,'2024-09-06 07:31:33','2024-09-06 07:31:33'),(45,5,2,1,'2024-09-06 07:31:33','2024-09-06 07:31:33'),(46,5,3,1,'2024-09-06 07:31:33','2024-09-06 07:31:33'),(47,5,4,1,'2024-09-06 07:31:33','2024-09-06 07:31:33'),(48,5,5,1,'2024-09-06 07:31:33','2024-09-06 07:31:33'),(49,5,6,1,'2024-09-06 07:31:33','2024-09-06 07:31:33'),(50,5,7,1,'2024-09-06 07:31:33','2024-09-06 07:31:33'),(51,5,10,1,'2024-09-06 07:31:33','2024-09-06 07:31:33'),(52,5,11,1,'2024-09-06 07:31:33','2024-09-06 07:31:33'),(53,5,12,1,'2024-09-06 07:31:33','2024-09-06 07:31:33'),(54,5,13,1,'2024-09-06 07:31:33','2024-09-06 07:31:33'),(55,5,14,1,'2024-09-06 14:17:42','2024-09-06 07:31:33');
/*!40000 ALTER TABLE `user_groups_companies_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_types`
--

DROP TABLE IF EXISTS `user_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_types`
--

LOCK TABLES `user_types` WRITE;
/*!40000 ALTER TABLE `user_types` DISABLE KEYS */;
INSERT INTO `user_types` (`id`, `name`, `created_at`, `updated_at`) VALUES (1,'Super Admin','2024-08-10 18:16:59','2024-08-10 18:16:59'),(2,'Mini Admin','2024-08-10 18:16:59','2024-08-10 18:16:59'),(3,'Marketer','2024-08-10 18:17:08','2024-08-10 18:17:08');
/*!40000 ALTER TABLE `user_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `avatar` text DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  `type_id` int(10) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_company_id_foriegn` (`company_id`),
  KEY `users_type_id_foreign` (`type_id`),
  CONSTRAINT `users_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `users_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `user_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `password`, `avatar`, `company_id`, `type_id`, `is_active`, `created_at`, `updated_at`) VALUES (1,'Mostafa Khaled','mustafakhaleedd@gmail.com','$2y$10$Bg6ugVPOhtSM3ipxxRCdQuMC2CmFB8/ONLahggAb2uXQaBgb.mNii','images/users/fa146662-f86b-439e-83e0-abd943598f78.png',3,1,1,'2024-06-20 08:51:11','2024-10-22 03:20:25'),(7,'Mohamed Eid','m.eid.saad403@gmail.com','$2y$10$Bg6ugVPOhtSM3ipxxRCdQuMC2CmFB8/ONLahggAb2uXQaBgb.mNii','images/users/fa146662-f86b-439e-83e0-abd943598f78.png',1,1,1,'2024-06-20 08:51:11','2024-09-07 22:10:55');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'alhashemya_group'
--

--
-- Dumping routines for database 'alhashemya_group'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-13 11:00:11
